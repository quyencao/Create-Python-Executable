#!/bin/bash

python3 /twain/code/main.py