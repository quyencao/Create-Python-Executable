#!/bin/bash

chmod +x /twain/code/install.sh

bash /twain/code/install.sh

# pip3 install -r /twain/code/requirements.txt
